

<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
    <?php
    include "project.css";
    ?>
   </style>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
   <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600&family=Poppins&display=swap" rel="stylesheet">

    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" type="image" href="pic\Screenshot (5).png" >
    <title> Fashion Basket Admin Login</title>
</head>
<body>


<div class="container log-con" >

<form action="adminlog.php" method="POST"  class="needs-validation " novalidate>
<div class="mb-3 ">
    <label for="email" class="form-label">Email:</label>
    <input required class="form-control " type="email" name="email" id="email" aria-describedby="invalid-feedback" placeholder="Enter your email" >
    <div class="invalid-feedback ">please enter your email ! it is MUST! example: asdf@sdf.df</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 
  
<div class="mb-3">
    <label for="password" class="form-label">password:</label>
    <input type="password" id="password"  name="password"
    placeholder="enter your password" class="form-control" required> 
    <div class="invalid-feedback ">please enter your password! it is MUST!</div> 
    <div class="valid-feedback ">looks good!</div>
</div>
 
    <button class="btn btn-ad mt-4 mb-5" type="submit" style="width:20%;"><b>Login</b></button>

    </form>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<script>

(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

</script>
</body>
</html>