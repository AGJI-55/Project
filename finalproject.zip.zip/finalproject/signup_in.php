<?php
// if(isset($_POST['update'])){
$first = $_POST['first'];
$sirname = $_POST['sirname'];
$email = $_POST['email'];
// $title= str_replace("'","\'", $title);

// $type= str_replace("'","\'", $type);
$pass = $_POST['password'];
$dob = $_POST['dob'];


include("connection.php");
$query= "INSERT INTO `login`(`id`, `first_name`, `last_name`, `email`, `password`, `dob`, `gender`, `profile_pic`) VALUES ('','$first','$sirname','$email','$pass','$dob','','')";
mysqli_query($con,$query);

header("location:login.php");
// }
?>