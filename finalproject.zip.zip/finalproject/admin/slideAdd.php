<?php
// if(isset($_POST['update'])){
$title = $_POST['name-id'];
$link = $_POST['anchor'];
$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

include("../connection.php");
$query="INSERT INTO  slider ( `photo`, `anchor`, `slider_name`) VALUES ('$image','$link','$title')";
mysqli_query($con,$query);

header("location:slide.php");
// }
?>