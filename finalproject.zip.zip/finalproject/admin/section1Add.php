<?php
// if(isset($_POST['update'])){
$title = $_POST['name-id'];
$title= str_replace("'","\'", $title);
$type = $_POST['type'];
$type= str_replace("'","\'", $type);
$price = $_POST['price'];
$discount = $_POST['Discount'];
$Dprice = $_POST['D_price'];
$total = $_POST['total'];
$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

$image1= $_FILES['image1']['name'];
$image_temp_1 = $_FILES['image1']['tmp_name'];
move_uploaded_file($image_temp_1 , "admin_pic/$image1");

$image2 = $_FILES['image2']['name'];
$image_temp_2 = $_FILES['image2']['tmp_name'];
move_uploaded_file($image_temp_2 , "admin_pic/$image2");

$image3 = $_FILES['image3']['name'];
$image_temp_3 = $_FILES['image3']['tmp_name'];
move_uploaded_file($image_temp_3 , "admin_pic/$image3");

include("../connection.php");
$query= "INSERT INTO  section ( `title_name`, `price`, `discount`,`discount_price`,`image`,`type`,`image1`,`image2`,`image3`,`total_img`) VALUES ('$title','$price','$discount','$Dprice','$image','$type','$image1','$image2','$image3','$total')";
mysqli_query($con,$query);

header("location:section1.php");
// }
?>