<?php
// if(isset($_POST['update'])){
$id= $_POST['admin'];
$logo = $_POST['logo-id'];
$logo2 = $_POST['logo-id2'];
$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

include("../connection.php");
$query="update navbar set logo_name='$logo',logo_last_name='$logo2', logo='$image' where id='$id' ";
mysqli_query($con,$query);

header("location:navbar.php");
// }
?>