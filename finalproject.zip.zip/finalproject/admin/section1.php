<?php
include("head.php");
include("../connection.php");
$query="select * from section";
$res=mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> Fashion Basket Admin dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>
<style>
<?php
include "main.css";
?>
 .swiper {
    --swiper-pagination-bullet-inactive-color: blue;
    --swiper-pagination-bottom: 0px;
                  width: 100% !important;
   height:300px;
}

.swiper-slide {
  text-align: center;
  font-size: 18px;

  display: flex;
  justify-content: center;
  align-items: center;
  width: 100% !important ;
  height:100% ;
  border-radius:5px ;
}
.swiper-slide a{
  width: 100% ;
  height:90% ;
  text-decoration: none;  
  color:black; 
}
.swiper-slide img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius:5px ;
}

</style>

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    
  </head>
  <body>
    

<div class=" con-tu" id="conyuyu">
<div class="row dic" style="@media(max-width:800px){padding-top:10%;}">


<?php
$a=1;
while($row=mysqli_fetch_array($res))
{
?>


<div class="card" style="width: 30%; text-align:center;  box-shadow: -1px 4px 5px rgba(255,69,0,0.6) ;">


<div class="swiper mySwiper">
    <div class="swiper-wrapper">
    <div class="swiper-slide"><img src="admin_pic/<?php echo $row['image'];?>" alt=""></div>

<?php
$i=1;
$y= $row['total_img'];
while($i<=$y){
  ?>
      <div class="swiper-slide"><a href=""><img src="admin_pic/<?php echo $row['image'.$i];?>" alt=""></a></div>
    
 
     <?php
   $i++;
}
   ?>
    </div>
  
    <div class="swiper-pagination"></div>
 
  </div>

  <div class="card-body" style="padding-top:5%;">
    <h5 class="card-title">Title : <b><?php echo $row['title_name']   ?></b> <br>
        Price:<?php echo $row['price'];?>  <br>
        discount: <?php echo $row['discount'];?> <br>
        discounted Price: <?php echo $row['discount_price']; ?><br>
        Type: <?php echo $row['type']; ?> <br>
          No. of images: <?php echo $row['total_img']; ?>
        </h5>
        <a href="section1_edit.php?section1_id=<?php echo $row['id']; ?>" class="btn  mt-2">Edit</a>
    <a href="section1_delete.php?section1_id=<?php echo $row['id']; ?>" class="btn  mt-2">Delete</a>
  </div>
</div>
 

<?php
$a++;
}
?>
</div> 
<br>
<center>
<a href="section1_add.php" class="btn  mt-2">Add New Item</a>
</center>
</div>


         <script src="ad.js"></script>
         <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
         <script>
var swiper = new Swiper(".mySwiper", {
 slidesPerView: 1,
//    spaceBetween: 25,
centeredSlides: true,
   loop: true,
   mousewheelControl: true,
   autoplay: {
      delay: 3000,
      pauseOnMouseEnter: true,
      running: true,
    },
   fade: 'true',
   grabCursor: 'true',
    pagination: {
      el: ".swiper-pagination",
     clickable: true,
      // dynamicBullets: true,
    },
   navigation: {
     nextEl: ".swiper-button-next",
     prevEl: ".swiper-button-prev",
   }, 
 });
   </script>
</body>