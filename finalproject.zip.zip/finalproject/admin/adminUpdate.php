<?php
// if(isset($_POST['update'])){
$admin= $_POST['admin'];
$email = $_POST['email-id'];
$name = $_POST['name'];
$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

include("../connection.php");
$query="update fashionadmin set fb_email='$email', fb_pic='$image', fb_name='$name' where id='$admin'";
mysqli_query($con,$query);

header("location:adminshow.php");
// }
?>