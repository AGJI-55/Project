<?php
// if(isset($_POST['update'])){
$id= $_POST['admin'];
$title = $_POST['title-id'];
$link = $_POST['link'];
$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

include("../connection.php");
$query="update secnav set title='$title', picture='$image',link='$link' where id='$id' ";
mysqli_query($con,$query);

header("location:secnav.php");
// }
?>