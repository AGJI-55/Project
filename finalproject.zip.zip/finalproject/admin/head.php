<?php
session_start();
if($_SESSION['admin']=="")
{
session_destroy();
header("Location:../index.php");
}
?>



 <!DOCTYPE html>
<html lang="en">
 <!-- <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        Govt Polytechnic  Roorkee Baheri Bareilly
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
-->




<style>
<?php
include "main.css";
?>
</style>

  <!--  <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
  </head> -->
  <body>
    <div class="main_box"> 
     <input type="checkbox" id="check" />
      <div class="btn_one">
        <label for="check" style="color: white">
          <i class="fa-solid fa-bars" id="icn"></i>
</label>
</div> 

<div class="rr">
       <div id="hbt">
       <h3 class="head ps-2 " ><b>Fashoin Basket Admin Dashboard </b></h3>
          </div> 
    
        <div class="hbt2">
           <div class="admin">
            <p>Admin <br> <h5 style="margin-top:-1%;"><b>Dashboard</b></h5></p>
           </div>

           <div class="admin-la">
        <h5> <p> <?php
                date_default_timezone_set('Asia/Kolkata');
                $currentTime=date('m/d/y h:i:s A');
                echo $currentTime;
                echo "|";

                echo $_SESSION['admin'];
                ?>
                </p></h5>
        </div>
</div>
  
<!-- <div class="container con-tu" id="contu">
         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium, delectus cum. Perferendis obcaecati nihil quod suscipit aspernatur neque quam minima illum debitis eveniet incidunt sequi placeat excepturi, rerum quisquam repudiandae.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque alias cum eum similique enim! Ad assumenda voluptatem quia esse quae dolore, delectus culpa reprehenderit impedit necessitatibus facere ea officiis ducimus!
            Explicabo similique dignissimos debitis deserunt dolore! Magni impedit facilis, maiores aut, quia aliquid dignissimos eaque minima fuga obcaecati perferendis nostrum dolores omnis ullam non totam et eum suscipit, praesentium odio?
            Quae eveniet voluptatibus eos delectus non, in fugit cum molestiae quibusdam earum vel quasi aperiam ea asperiores repellat repellendus libero quod ad consectetur minima nobis perferendis quas harum impedit? Ut!
            Eos, suscipit ab distinctio adipisci saepe officia! Obcaecati optio voluptatum repudiandae vel. Praesentium, cumque adipisci rerum officia odit veritatis quibusdam natus voluptas perferendis nostrum id quaerat ipsa mollitia quod optio?
            Fuga porro error deleniti enim amet! Perspiciatis dolor quae molestiae, rerum exercitationem aspernatur soluta voluptatibus dicta atque nobis, nemo, nisi debitis odit? Soluta eaque repellendus saepe consectetur dolorum laboriosam nostrum.
            Consequatur doloremque non blanditiis architecto sint! Asperiores vero quae tenetur, facilis totam quis non. Totam repellendus quidem quas praesentium veniam quam. Magni eos exercitationem harum voluptates eveniet repellendus nobis aperiam.
            Consectetur deserunt aliquam voluptatibus ut a minus magnam earum adipisci debitis! Sed nostrum consequatur odit eaque eveniet impedit, repudiandae assumenda, veritatis quo laudantium natus! Ipsam, qui corrupti? Neque, veritatis similique?
            Autem possimus sed nisi itaque dolorum, a tenetur beatae quisquam, magnam optio corporis est vero adipisci et animi odit recusandae, atque sit illum! Porro soluta est laudantium iusto voluptatum atque.
            In, beatae recusandae! Fugit, quia! Minus enim quasi inventore consequatur illum reiciendis voluptate aspernatur, ipsam non pariatur fugiat. Voluptate asperiores fugiat similique officiis soluta dolorem consequatur? Doloremque voluptates sit harum.
            Similique tempora consequatur quibusdam neque optio! Nam reprehenderit libero deserunt eligendi amet tempora voluptas? Quaerat temporibus suscipit eaque maxime in deleniti veniam neque exercitationem, expedita iusto repellat eius omnis. Quidem.
            Aspernatur sunt similique consequatur voluptate omnis culpa laborum quia, ut maxime, nobis odio magni earum nostrum tenetur porro necessitatibus corrupti quae, fugit dolor vero? Minus nobis debitis facere a obcaecati!
            Ullam eius neque eos maiores enim perferendis totam culpa harum architecto officiis unde possimus dicta, voluptatum explicabo illum voluptatibus delectus asperiores nostrum eligendi repellat. Vero dolorem quaerat atque necessitatibus cumque.
            Praesentium, alias consequatur nemo repellendus quo autem soluta, ea aliquid accusantium iste nulla hic, consectetur tenetur ullam! Reiciendis consectetur eaque autem officia veniam rem sapiente ipsum architecto illum, nemo aliquid?
            Esse, laboriosam  voluptatibus laudantium ad eum dignissimos tenetur libero minus facilis magnam, autem alias debitis unde commodi quos! Est voluptatibus aliquam doloribus vitae aliquid. Omnis commodi esse maiores praesentium.
            Quos accusamus numquam alias est provident ex iure architecto necessitatibus aut nihil. Corporis delectus mollitia ratione aliquam suscipit quae laboriosam accusantium libero vel nesciunt deleniti tenetur, maxime inventore in! Fugiat?
          </p>
         </div>  -->
</div>

      <div class="sidebar_menu">
        
        <div class="logo">
          <a href="dashboard.php"><b>Admin |Dashboard</b></a>
        </div>

        <div class="btn_two">
          <label for="check" style="color: grey">
            <i class="fa-solid fa-xmark" id="icn2"></i>
          </label>
        </div>

        <div class="menu">
          <ul>
            <li>
              <a href="adminshow.php" >   <i class="fa-solid fa-image"></i><?php
                echo $_SESSION['admin'];
                ?></a>
            </li>
            <li>
            
              <a href="secnav.php">  <i class="fa-solid fa-arrow-up-right-from-square"></i> NavOptions</a>
            </li>
            <li>
              <a href="navbar.php">  <i class="fa-solid fa-photo-film"></i>  NavLogo</a>
            </li>
            <li>
             
              <a href="slide.php"> <i class="fa-solid fa-calendar-days"></i> Sliders</a>
            </li>
            <li>
             
              <a href="section1.php"> <i class="fa-solid fa-store"></i> Section</a>
            </li>
            <li>
             
              <a href="#"> <i class="fa-solid fa-phone"></i> Section2</a>
            </li>
            <li>
              
              <a href="#"><i class="fa-regular fa-comments"></i> Feedback</a>
            </li>
            
          </ul>
        </div>
<!-- 
        <div class="social_media">
          <ul>
            <a href="#"><i class="fa-brands fa-facebook"></i></i></a>
            <a href="#"><i class="fa-brands fa-twitter"></i></a>
            <a href="#"><i class="fa-brands fa-instagram"></i></i></a>
            <a href="#"><i class="fa-brands fa-youtube"></i></a>
          </ul>
        </div> -->
      </div>
    </div>


    
  </body>
</html>