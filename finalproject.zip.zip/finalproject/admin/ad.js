let ino = document.querySelector("#icn");

let ino2 = document.querySelector("#icn2");
let con1 = document.querySelector("#conyuyu");

ino.addEventListener("click",function (){
     con1.style.width = "60%";
     con1.style.right = "0";
     ino.style.transition = "all 0.5s linear";
});

ino2.addEventListener("click", function(){
   con1.style.width = "100%";
});




