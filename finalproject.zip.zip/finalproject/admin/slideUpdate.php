<?php
// if(isset($_POST['update'])){
$id= $_POST['admin'];
$title = $_POST['name-id'];
$link = $_POST['anchor'];
$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

include("../connection.php");
$query="update slider set slider_name='$title', photo='$image',anchor='$link' where id='$id' ";
mysqli_query($con,$query);

header("location:slide.php");
// }
?>