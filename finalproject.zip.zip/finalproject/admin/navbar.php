<?php
include("head.php");
include("../connection.php");

$query="select * from navbar";
$res=mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> Fashion Basket Admin dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  
<style>
<?php
include "main.css";
?>
</style>

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    
  </head>
  <body>
    






<div class=" con-tu" id="conyuyu">
<div class="row dic" style="@media(max-width:800px){padding-top:10%;}">           
<?php
$a=1;
while($row=mysqli_fetch_array($res))
{
?>


<div class="card" style="width: 30%; text-align:center;  box-shadow: -1px 4px 5px rgba(255,69,0,0.6) ;">
  <img src="admin_pic/<?php echo $row['logo']?>" class="card-img-top" alt="..." style="width:50%;height:250px;margin:0 auto;">
  <div class="card-body" style="padding-top:5%;">
    <h5 class="card-title">Title : <b><?php echo $row['logo_name']; echo $row['logo_last_name'];   ?></b> 
        </h5>
        <a href="navbar_edit.php?nav_id=<?php echo $row['id']; ?>" class="btn  mt-2">Edit</a>
    <a href="navbar_delete.php?nav_id=<?php echo $row['id']; ?>" class="btn  mt-2">Delete</a>
  </div>
</div>
 

<?php
$a++;
}
?>
</div> </div>


         <script src="ad.js"></script>

</body>