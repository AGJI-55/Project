<?php
$admin_id=$_REQUEST['section1_id'];
include("../connection.php");
include("head.php");
$query="select * from section where id='$admin_id'";
$res=mysqli_query($con,$query);
if($data=mysqli_fetch_assoc($res))
{
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> Fashion Basket Admin dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  
<style>
<?php
include "main.css";
?>
</style>

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    
  </head>
  <body>
    
<div class=" con-tu" id="conyuyu" style="z-index:20;">
<div class="row" style="@media(max-width:800px){padding-top:22%;} ">           

<form action="section1Update.php" method="post" enctype="multipart/form-data"  class="needs-validation " novalidate  style="box-shadow: -1px 4px 5px rgba(255,69,0,0.6) ;padding-top:5%;">

<input  class="form-control " type="hidden" name="admin"  value="<?php echo $data['id']?>">


<div class="mb-3 ">
    <label for="title" class="form-label">Title:</label>
    <input required class="form-control " type="text" name="name-id" id="title" aria-describedby="invalid-feedback" autocomplete="off" value="<?php echo $data['title_name'];?>">
    <div class="invalid-feedback ">please enter your title..</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 

<div class="mb-3 ">
    <label for="type" class="form-label">Type:</label>
    <input required class="form-control " type="text" name="type" id="type" aria-describedby="invalid-feedback" autocomplete="off" value="<?php echo $data['type'];?>">
    <div class="invalid-feedback ">please enter your type..</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 

<div class="mb-3 ">
    <label for="Price" class="form-label">Price:</label>
    <input required class="form-control " type="text" name="price" id="Price" aria-describedby="invalid-feedback" autocomplete="off" value="<?php echo $data['price']?>">
    <div class="invalid-feedback ">please enter your link..</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 
<div class="mb-3 ">
    <label for="discount" class="form-label">Discount:</label>
    <input required class="form-control " type="text" name="Discount" id="discount" aria-describedby="invalid-feedback" autocomplete="off" value="<?php echo $data['discount']?>">
    <div class="invalid-feedback ">please enter your link..</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 

<button onclick="per()" class="btn" style="width:30%;"> get discounted price </button>

<div class="mb-3 ">
    <label for="d_Price" class="form-label">Discounted Price:</label>
    <input required class="form-control " type="text" name="D_price" id="d_Price" aria-describedby="invalid-feedback" autocomplete="off" value="<?php echo $data['discount_price']?>">
    <div class="invalid-feedback ">please enter your link..</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 


<div class="mb-3">
    <label for="pic" class="form-label">Pic:</label>
    <input required type="file" id="pic"  name="image" value= "<?php echo $data['image'];?>" class="form-control" > 
</div>

<div class="mb-3">
    <label for="pic1" class="form-label">Pic:</label>
    <input required type="file" id="pic1"  name="image1" value= "<?php echo $data['image1'];?>" class="form-control" > 
</div>
<div class="mb-3">
    <label for="pic2" class="form-label">Pic:</label>
    <input required type="file" id="pic2"  name="image2" value= "<?php echo $data['image2'];?>" class="form-control" > 
</div>
<div class="mb-3">
    <label for="pic3" class="form-label">Pic:</label>
    <input required type="file" id="pic3"  name="image3" value= "<?php echo $data['image3'];?>" class="form-control" > 
</div>

<div class="mb-3 ">
    <label for="total" class="form-label">Total no. of Images:</label>
    <input required class="form-control " type="text" name="total" id="total" aria-describedby="invalid-feedback" autocomplete="off" value="<?php echo $data['total_img']?>">
    <div class="invalid-feedback ">please enter your link..</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 


    <input type="submit" class="btn  mt-4 mb-5" name="edit" value="edit"  style="width:30%;">

    </form>

</div> </div>


<script>
    function per() {
    let percent = document.getElementById("discount").value;
     
     // Method returns the element of num id
     let num = document.getElementById("Price").value;
     let out = (num / 100) * percent;
     let result = num - out ;
     document.getElementById("d_Price").value = Math.floor(result);
 
    }

</script>       
         <script>

(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

</script>
    
<script>
  let file=document.querySelector("#pic");
  console.dir(file);
  </script>
<script src="ad.js"></script>
</body>
</html>
<?php
}
?>