<?php
$id= $_POST['admin'];
$title = $_POST['name-id'];
$title= str_replace("'","\'", $title);
$price = $_POST['price'];
$type = $_POST['type'];
$type= str_replace("'","\'", $type);
$discount = $_POST['Discount'];
$Dprice = $_POST['D_price'];
$total = $_POST['total'];

$image = $_FILES['image']['name'];
$image_temp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_temp , "admin_pic/$image");

$image1= $_FILES['image1']['name'];
$image_temp_1 = $_FILES['image1']['tmp_name'];
move_uploaded_file($image_temp_1 , "admin_pic/$image1");

$image2 = $_FILES['image2']['name'];
$image_temp_2 = $_FILES['image2']['tmp_name'];
move_uploaded_file($image_temp_2 , "admin_pic/$image2");

$image3 = $_FILES['image3']['name'];
$image_temp_3 = $_FILES['image3']['tmp_name'];
move_uploaded_file($image_temp_3 , "admin_pic/$image3");



include("../connection.php");
$query= "update section set title_name= '$title', price='$price', discount='$discount', discount_price='$Dprice', image='$image',type='$type', image1='$image1', image2='$image2', image3='$image3',total_img='$total' where id ='$id' ";
mysqli_query($con,$query);
header("location:section1.php");
// }
?>