<?php
$admin_id=$_REQUEST['product_id'];
include("connection.php");
$query="select * from section where id='$admin_id'";
$res=mysqli_query($con,$query);
if($data=mysqli_fetch_assoc($res))
{
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

.swiper {
    --swiper-pagination-bullet-inactive-color: blue;
    --swiper-pagination-bottom: 0px;
                  width: 100% !important;
  height: 50vh;
}

.swiper-slide {
  text-align: center;
  font-size: 18px;
  background: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100% !important ;
  height:100% ;
  border-radius:5px ;
}
.swiper-slide a{
  width: 100% ;
  height:100% ;
  text-decoration: none;  
  color:black; 
}
.swiper-slide img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius:5px ;
}

.swiper-button-next{
    right: 0;
    top: var(--swiper-navigation-top-offset,40%);
  }
  .swiper-button-prev{
     left: 0; 
     top: var(--swiper-navigation-top-offset,40%);
  }
  .swiper-button-next::after{
    display: none;
  }
  .swiper-button-prev::after{
    display: none;
  }

</style>
   <style>
    <?php
    include "project.css";
    ?>
   </style>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
   <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600&family=Poppins&display=swap" rel="stylesheet">

    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" type="image" href="pic\Screenshot (5).png" >
    <title> Fashion Basket</title>
</head>
<body>



<?php
include "head.php";

?>

<div class="container" style="padding-bottom:5% !important; padding-top:1%;width:40% !important; height:40% !important; margin-left:0;">


<div class="swiper mySwiper">
    <div class="swiper-wrapper">
    <div class="swiper-slide"><a href="full.php?full_id=<?php echo $data['image']; ?>"><img src="admin/admin_pic/<?php echo $data['image'];?>" alt=""></a></div>

<?php
$i=1;
$y= $data['total_img'];
while($i<$y){
  ?>
      <div class="swiper-slide"><a href="full.php?full_id=<?php echo $data['image'.$i]; ?>"><img src="admin/admin_pic/<?php echo $data['image'.$i];?>" alt=""></a></div>
    
     <?php
   $i++;
}
   ?>
    </div>
  
    <div class="swiper-button-next"><i class="fa-solid fa-caret-right fa-bounce fa-xl" style="color: #ff4500;"></i></div>
    <div class="swiper-button-prev"><i class="fa-solid fa-caret-left fa-bounce fa-xl" style="color: #ff4500;"></i></div>
 
  </div>



</div>

<?php
include "footer.php";
?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
var swiper = new Swiper(".mySwiper", {
 slidesPerView: 1,
//    spaceBetween: 25,
centeredSlides: true,
   loop: true,
   mousewheelControl: true,
   autoplay: {
      delay: 3000,
      pauseOnMouseEnter: true,
      running: true,
    },
   fade: 'true',
   grabCursor: 'true',
  //  pagination: {
  //    el: ".swiper-pagination",
  //    clickable: true,
  //    dynamicBullets: true,
  //  },
   navigation: {
     nextEl: ".swiper-button-next",
     prevEl: ".swiper-button-prev",
   },  });
   </script>
</body>
</html>


<?php
}
?>