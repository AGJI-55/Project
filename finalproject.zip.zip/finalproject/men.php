<?php
include("connection.php");
$sql="select * from section where type='men'";
$result=mysqli_query($con,$sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
    <?php
    include "project.css";
    ?>
   </style>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
   <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600&family=Poppins&display=swap" rel="stylesheet">

    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" type="image" href="pic\Screenshot (5).png" >
    <title> Fashion Basket</title>
</head>
<body>



<?php
include "head.php";

?>

<div class="container-fluid" style="height:100% !important; width:100% !important; padding-top:10vh !important;     background-color: rgba(224, 240, 247,0.6) !important;">
<div class="row " style="padding-bottom:2vw !important; padding-top:2vh !important;">
<h3 class="h12 "><b ><u> MEN'S WEAR</u></b></h3><br>
</div>
<div class="row row-1 row-cols-lg-3 row-cols-md-2 row-cols-sm-1">
<?php 
            while($sres=mysqli_fetch_array($result)){
            ?>

<a href="#" class="card-a">
<div class="card sard col " style="width: 18rem; height:20rem;">
  <img src="admin/admin_pic/<?php echo $sres['image'];?>" class="card-img-top card-img-top-1" alt="..." style="height:15rem;" >
  <div class="card-body card-body-1">
  <p class="card-text" style="line-height:12%;"> <?php echo $sres['title_name']; ?> <br></p>
                                             <p> <b style="font-size:larger;"> <i class="fa-solid fa-indian-rupee-sign"></i><?php echo $sres['discount_price']; ?> </b> 
                                               <u style="text-decoration:line-through; font-size:medium;"> &nbsp;<?php echo $sres['price']; ?> </u>
                                              <b style="color:orangered;font-size:small;"> &nbsp;  <?php echo $sres['discount']; ?>% </b> </p>
  </div>
</div>
</a>

<?php
            }
            ?>
</div>
</div>

<?php
include "footer.php";
?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
</body>
</html>

