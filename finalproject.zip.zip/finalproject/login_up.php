<?php
session_start();
$email=$_POST['email'];
//echo $email;
$password=$_POST['password'];
//echo $password;
include("connection.php");
$check="select * from login where email='$email' and password='$password'";
$nam = "select first_name from login where email='$email' and password='$password'";

$res=mysqli_query($con,$check) or die("query failed!");
$res2=mysqli_query($con,$nam);

if($row=mysqli_fetch_array($res2))
{
$_SESSION['admin']=$row['first_name'];
}

if($row=mysqli_fetch_array($res))
{
   $id=$row['id'];
// $_SESSION['admin']=$email;
header("location:index.php?id={$id}");
}
else{ 
// header("location:admin_log.php");
echo "<script> alert('You enter wrong password or email!! ');window.location.href='login.php';</script>";
}

?>