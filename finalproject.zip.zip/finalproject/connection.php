<?php 
$con=mysqli_connect("localhost","root","","fashionbasket",3308);
?>