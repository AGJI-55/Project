<?php
session_start();
$email=$_POST['email'];
//echo $email;
$password=$_POST['password'];
//echo $password;
include("connection.php");
$check="select * from fashionadmin where fb_email='$email' and password='$password'";
$nam = "select fb_name from fashionadmin where fb_email='$email' and password='$password'";

$res=mysqli_query($con,$check) or die("query failed!");
$res2=mysqli_query($con,$nam);

if($row=mysqli_fetch_array($res2))
{
$_SESSION['admin']=$row['fb_name'];
}

if($row=mysqli_fetch_array($res))
{
// $_SESSION['admin']=$email;
header("location:admin\dashboard.php");
}
else{ 
// header("location:admin_log.php");
echo "<script> alert('You enter wrong password or email!! ');window.location.href='admin.php';</script>";
}

?>