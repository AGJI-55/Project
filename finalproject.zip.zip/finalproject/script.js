let options = document.querySelectorAll("#dd");

 let c = new Date();
  let cc = c.getDate();
for(option of options){
   if(option.value== cc){
    option.setAttribute( "selected",true);
   }
}


let years = document.querySelectorAll("#yy");

let x = new Date().toLocaleString("default",{month : 'long'});
  
for(year of years){
   if(year.value== x){
    year.setAttribute( "selected",true);
   }
}