<?php
include("connection.php");
$query="select * from slider";
$query6="select type from section where id='3000'";
$query2="select * from section where type='men' limit 5";
$query3="select * from section where type='women' limit 5";
$query4="select * from section where type='kid' limit 5";
$query5="select * from section where  type!='men' and type!='women' and type!='kid' limit 5";
$res=mysqli_query($con,$query);
$res2=mysqli_query($con,$query2);
$res3=mysqli_query($con,$query3);
$res4=mysqli_query($con,$query4);
$res5=mysqli_query($con,$query5);
$res6=mysqli_query($con,$query6);
?>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<style>

    .swiper {
        --swiper-pagination-bullet-inactive-color: blue;
        --swiper-pagination-bottom: 0px;
                      width: 99%;
      height: 40vh;
    }

    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 90% ;
      height:90% ;
      border-radius:5px ;
    }
  .swiper-slide a{
      width: 100% ;
      height:100% ;
      text-decoration: none;  
      color:black; 
  }
    .swiper-slide img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius:5px ;
    }

.swiper-pagination-bullet-active{
    background-color: orangered;
    border: 0.2px solid black;
}
  </style>



<div class="swiper mySwiper">
    <div class="swiper-wrapper">

    <?php 
            while($row=mysqli_fetch_array($res)){
            ?>

      <div class="swiper-slide"><a href="<?php echo $row['anchor'];?>" target="_blank"><img src="admin/admin_pic/<?php echo $row['photo'];?>" alt=""> </a></div>
      <!-- <div class="swiper-slide"><a href="">Slide 2</a></div>
      <div class="swiper-slide"><a href="">Slide 3</a></div>
      <div class="swiper-slide"><a href="">Slide 4</a></div>
      <div class="swiper-slide"><a href="">Slide 5</a></div>
      <div class="swiper-slide"><a href="">Slide 6</a></div>
      <div class="swiper-slide"><a href="">Slide 7</a></div>
      <div class="swiper-slide"><a href="">Slide 8</a></div>
      <div class="swiper-slide"><a href="">Slide 9</a></div> -->

<?php
            }
?>

    </div>
  
    <div class="swiper-pagination"></div>  
  </div>


  <div class="container-fluid menka ">
  
  <h4 style="margin-left: 2rem;"><b>MEN'S WEAR</b></h4>
  
  <div class="container flipcon">
 
  <?php 
            while($row2=mysqli_fetch_array($res2)){
            ?>
 <a href="product.php?product_id=<?php echo $row2['id']; ?>" class="card-aa" target="_blank">  
   <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="admin/admin_pic/<?php echo $row2['image'];?>" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text" style="line-height:12%;"> <?php echo $row2['title_name']; ?> <br></p>
                                             <p> <b style="font-size:larger;"> <i class="fa-solid fa-indian-rupee-sign"></i><?php echo $row2['discount_price']; ?> </b> 
                                               <u style="text-decoration:line-through; font-size:medium;"> &nbsp;<?php echo $row2['price']; ?> </u>
                                              <b style="color:orangered;font-size:small;"> &nbsp;  <?php echo $row2['discount']; ?>% </b> </p>
                                           </div>
                              </div>
                                     <div class="back">
                                     <img src="admin/admin_pic/<?php echo $row2['image'];?>" class="card-img" alt="...">
                                             <!-- <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p> -->
                                     </div>
                  </div>
            </div>
            </a>

            <?php
            }     
            ?>
<!-- 
            <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="pic\men-pic.webp" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text"> <b>Government Polytechnic Roorkee Baheri Bareilly </b></p>
                                           </div>
                              </div>
                                     <div class="back">
                                             <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p>
                                     </div>
                  </div>
            </div>
            <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="pic\men-pic.webp" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text"> <b>Government Polytechnic Roorkee Baheri Bareilly </b></p>
                                           </div>
                              </div>
                                     <div class="back">
                                             <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p>
                                     </div>
                  </div>
            </div>

            <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="pic\men-pic.webp" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text"> <b>Government Polytechnic Roorkee Baheri Bareilly </b></p>
                                           </div>
                              </div>
                                     <div class="back">
                                             <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p>
                                     </div>
                  </div>
            </div>

            <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="pic\men-pic.webp" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text"> <b>Government Polytechnic Roorkee Baheri Bareilly </b></p>
                                           </div>
                              </div>
                                     <div class="back">
                                             <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p>
                                     </div>
                  </div>
            </div> -->

</div>
  </div>

  <div class="container-fluid menka">
   
   <h4 style="margin-left: 2rem;"><b>WOMEN'S WEAR</b></h4>
    
   <div class="container flipcon">
   <?php 
            while($row3=mysqli_fetch_array($res3)){
            ?>
 <a href="product.php?product_id=<?php echo $row3['id']; ?>" class="card-aa" target="_blank">  
  <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="admin/admin_pic/<?php echo $row3['image'];?>" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text" style="line-height:12%;"> <?php echo $row3['title_name']; ?> <br></p>
                                             <p> <b style="font-size:larger;"> <i class="fa-solid fa-indian-rupee-sign"></i><?php echo $row3['discount_price']; ?> </b> 
                                               <u style="text-decoration:line-through; font-size:medium;"> &nbsp;<?php echo $row3['price']; ?> </u>
                                              <b style="color:orangered;font-size:small;"> &nbsp;  <?php echo $row3['discount']; ?>% </b> </p>
                                           </div>
                              </div>
                                     <div class="back">
                                     <img src="admin/admin_pic/<?php echo $row3['image'];?>" class="card-img" alt="...">
                                             <!-- <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p> -->
                                     </div>
                  </div>
            </div>
            </a>

            <?php
            }     
            ?>

 </div>
   </div>
 
   <div class="container-fluid menka">
   
   <h4 style="margin-left: 2rem;"><b>KID'S WEAR</b></h4>
    
   <div class="container flipcon">
   <?php 
            while($row4=mysqli_fetch_array($res4)){
            ?>
 <a href="product.php?product_id=<?php echo $row4['id']; ?>" class="card-aa" target="_blank">  
   <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                             <div class="front">
                                   <img src="admin/admin_pic/<?php echo $row4['image'];?>" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text" style="line-height:12%;"> <?php echo $row4['title_name']; ?> <br></p>
                                             <p> <b style="font-size:larger;"> <i class="fa-solid fa-indian-rupee-sign"></i><?php echo $row4['discount_price']; ?> </b> 
                                               <u style="text-decoration:line-through; font-size:medium;"> &nbsp;<?php echo $row4['price']; ?> </u>
                                              <b style="color:orangered;font-size:small;"> &nbsp;  <?php echo $row4['discount']; ?>% </b> </p>
                                           </div>
                              </div>
                                     <div class="back">
                                     <img src="admin/admin_pic/<?php echo $row4['image'];?>" class="card-img" alt="...">
                                             <!-- <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p> -->
                                     </div>
                  </div>
            </div></a>
      
<?php
            }
?>
 
 </div>
   </div>
 
   <div class="container-fluid menka">
   
   <h4 style="margin-left: 2rem;"><b>OTHER TRENDS</b></h4>
    
   <div class="container flipcon">
   <?php 
            while($row5=mysqli_fetch_array($res5)){
            ?>
 <a href="product.php?product_id=<?php echo $row5['id']; ?>" class="card-aa" target="_blank">  
   <div class="card flip-card" style="width: 230px;">
                 <div class="card-inner">
                
                             <div class="front">
                                   <img src="admin/admin_pic/<?php echo $row5['image'];?>" class="card-img-top imgtop" alt="...">
                                         <div class="card-body">
                                               <p class="card-text" style="line-height:12%;"> <?php echo $row5['title_name']; ?> <br></p>
                                             <p> <b style="font-size:larger;"> <i class="fa-solid fa-indian-rupee-sign"></i> <?php echo $row5['discount_price']; ?> </b> 
                                               <u style="text-decoration:line-through; font-size:medium;"> &nbsp;<?php echo $row5['price']; ?> </u>
                                              <b style="color:orangered;font-size:small;"> &nbsp;  <?php echo $row5['discount']; ?>% </b> </p>
                                           </div>
                              </div> 
                                     <div class="back">
                                     <img src="admin/admin_pic/<?php echo $row5['image'];?>" class="card-img" alt="...">
                                             <!-- <h5> <b>Government Polytechnic Roorkee Baheri Bareilly </b></h5>
                                                   <p class="card-text"><b> Pincode : 243501</b><br>
                                                     <b>Email : info.gprbb@gmail.com </b><br><b>State : Uttar Pradesh </b>
                                                     <br><br><br>Government of Uttar pradesh</p> -->
                                     </div>
                  </div>
            </div>
            </a>
            
<?php
            }
?>
 
        

             
 </div>
   </div>
 
 
 
 


<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
var swiper = new Swiper(".mySwiper", {
 slidesPerView: 1,
//    spaceBetween: 25,
   loop: true,
   mousewheelControl: true,
   autoplay: {
      delay: 3000,
      pauseOnMouseEnter: true,
      running: true,
    },
   fade: 'true',
   grabCursor: 'true',
   pagination: {
     el: ".swiper-pagination",
     clickable: true,
    //  dynamicBullets: true,
   },  });

   </script>