<?php
include("connection.php");
$query="select * from secnav";
$query2="select * from navbar";
$res=mysqli_query($con,$query);
$res2=mysqli_query($con,$query2);

?>



<nav class="navbar navbar-expand-sm MNAV">
  <div class="container-fluid">
  <?php 
            $row2=mysqli_fetch_array($res2);
            $row3=mysqli_fetch_array($resout)
            ?>
    <a class="navbar-brand ps-2 log" href="index.php">
        <div class="fash">
   <div class="i pe-2"> <img src="admin/admin_pic/<?php echo $row2['logo']; ?>" alt="Logo" width="50" height="50" class="d-inline-block align-text-top"></div>
     <div class="fashion"><p><b style="color:blue; font-size:x-large;"><i><?php echo $row2['logo_name'];?> </i></b> <br><b style="color:orangered; font-size:medium;" ><?php echo $row2['logo_last_name'];?> </b></p></div>
</div>
    </a>
    <form class="d-flex form-nav"   role="search">
    <button class="btn search-btn  form-nav2 " type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
        <input class="form-control me-1  form-nav1"  type="search" placeholder="           Search" aria-label="Search">
      </form>
      <div class="card togcar">
      <button class="navbar-toggler card-header" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      <div class="collapse navbar-collapse card-body " id="navbarSupportedContent">
     
      <?php if(!$id){  ?>
        <a class="nav-link me-5  i-link" id="profi" href="login.php">
        <i class="fa-regular fa-user"></i> Login</a>
     <?php } else {  ?>
        <a class="nav-link me-5  i-link" id="profi" href="">
        <i class="fa-regular fa-user"></i>   <?php echo $row3['first_name']; ?>  </a>
   <?php   }
      ?>
        <a class="nav-link me-5 i-link sign-up" href="signup.php"><i class="fa-solid fa-user-plus"></i> SignUp</a>
        <a class="nav-link me-5 i-link" href="#"><i class="fa-solid fa-cart-shopping"></i> Cart</a>
        <!-- <div class="d"><a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul></div> -->
</div> 
</div>
  </div>
</nav>

<nav class="navbar  sec-nav" >
  <div class="container-fluid">
    <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button> -->
    <div class="navbarNav">
      <ul class="navbar-nav">

      <?php 
            while($row=mysqli_fetch_array($res)){
            ?>

        <li class="nav-item">
         <div class="can"> <a class="nav-link n2  " target="_blank" aria-current="page" href="<?php echo $row['link']; ?>">
         <div class="card card1" >
  <img src="admin/admin_pic/<?php echo $row['picture'] ?>" class="card-img-top" alt="..." style="border-radius:2px!important;">
  <div class="card-body p-0">
    <p><?php echo $row['title'];     ?></p>
  </div>
</div></a>
</div>
        </li>

        <?php
            }
               ?>

        <!-- <li class="nav-item">
        <div class="can"> <a class="nav-link n2  " aria-current="page" href="#">
         <div class="card card1" style="width: 6rem; height:6rem;">
  <img src="pic\men-pic.webp" class="card-img-top" alt="..." style="border-radius:2px!important;">
  <div class="card-body p-0">
    <p>Women</p>
  </div>
</div></a>
</div>      
  </li>

        <li class="nav-item">
       <div class="can"> <a class="nav-link n2  " aria-current="page" href="#">
         <div class="card card1" style="width: 6rem; height:6rem;">
  <img src="pic\men-pic.webp" class="card-img-top" alt="..." style="border-radius:2px!important;">
  <div class="card-body p-0">
    <p>Kids</p>
  </div>
</div></a>
</div>         </li>
        <li class="nav-item">
        <div class="can"> <a class="nav-link n2  " aria-current="page" href="#">
         <div class="card card1" style="width: 6rem; height:6rem;">
  <img src="pic\men-pic.webp" class="card-img-top" alt="..." style="border-radius:2px!important;">
  <div class="card-body p-0">
    <p>Electronics Accessories</p>
  </div>
</div></a>
</div>         </li>
        <li class="nav-item">
        <div class="can"> <a class="nav-link n2  " aria-current="page" href="#">
         <div class="card card1" style="width: 6rem; height:6rem;">
  <img src="pic\men-pic.webp" class="card-img-top" alt="..." style="border-radius:2px!important;">
  <div class="card-body p-0">
    <p>Beauty</p>
  </div>
</div></a>
</div>         </li>
        <li class="nav-item">
        <div class="can"> <a class="nav-link n2  " aria-current="page" href="#">
         <div class="card card1" style="width: 6rem; height:6rem;">
  <img src="pic\men-pic.webp" class="card-img-top" alt="..." style="border-radius:2px!important;">
  <div class="card-body p-0">
    <p>Domestic Accessories</p>
  </div>
</div></a>
</div>         </li> -->
      </ul>
    </div>
  </div>
</nav>
