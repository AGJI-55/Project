
<div class="container-fluid " style="background-color:rgba(0,0,0,0.9); color:white; padding:2% !important; ">
<div class="row foot-foot">
    <div class="foot">
    <h5><i class="fa-solid fa-phone-volume fa-xl  icn" style=" margin:5px;"></i>&nbsp;&nbsp;&nbsp; <b>Contact</b></h5> <br>
     <p><i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i>      &nbsp;&nbsp;&nbsp; <a href="" target="_blank" class="foot-link"><b>Contact Us</b></a> <br>
  <i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i>     &nbsp;&nbsp;&nbsp;  <a href="" target="_blank" class="foot-link"><b>About Us</b></a>   <br>
  <i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp;  <a href="" target="_blank" class="foot-link"><b>Fashion Basket Informations</b></a>  <br>
  <i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp; &nbsp;<b>Email: </b> fashionbasket@gmail.com
</p>
    </div>

    <div class="foot">
  <h5><b>Usefull Links</b></h5> <br>
    <p><i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp; &nbsp; <a href="" target="_blank" class="foot-link"><b>Men's Wear</b></a> <br> 
    <i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp; &nbsp; <a href="" target="_blank" class="foot-link"><b>Women's Wear</b></a>  <br> 
        <i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp; &nbsp; <a href="" target="_blank" class="foot-link"><b>Trendings</b></a>  <br>  
        <i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp; &nbsp; <a href="" target="_blank" class="foot-link"><b>Fashion Basket Suggests</b></a>  <br>  
</p>
</div>


<div class="foot">
  <h5><b>Other Links</b></h5> <br>
    <p><i class="fa-solid fa-caret-right fa-flip" style="color: #ff4500;"></i> &nbsp; &nbsp; &nbsp; <a href="#" target="_blank" class="foot-link"><b>Login</b></a> <br> 
   
</p>
</div>

<h6 align="center">Fashion Basket © 2024. All Rights Reserved. Website is Developed by <a href="https://www.instagram.com/ayush_.gupta/" target="_blank" class="foot-link"><b><u>Ayush Gupta</u> <i class="fa-brands fa-instagram"></i></b></a> <a href="https://www.facebook.com/profile.php?id=100073773333818" target="_blank" ><b><i class="fa-brands fa-facebook"></i></b></a></h6>

</div>
</div>


