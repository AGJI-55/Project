<?php
include("connection.php");
$query="select * from navbar";
$res=mysqli_query($con,$query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <style>
    body{
        background: rgb(240, 237, 237) !important;
    }
   .container{
    display: flex;
    flex-direction:row;
    justify-content:space-around;
    padding: 10%;
   }
   .heee{
    padding-top:5%;
  
   }
    .container-1{
      box-shadow: rgba(99, 99, 99, 0.5) 0px 4px 12px 0px;
        width:40% !important;
        background:white;
 
  border-radius: 5%;
  padding:2% ;
    }
    form{
        background:white;
    
    }
    input{
        width: 90% !important;
        margin:5% !important;
        padding: 2% !important;
        }
        .btn{
    background-color: orangered !important;
    color: white !important;
    font-size: x-large !important;
}
.btn:hover{
    background: none !important;
    color: orangered !important;
    border: 1px solid orangered !important;
}
.btn-2{
    background-color: blue !important;
    color: white !important;
    font-size: x-large !important;
         width: 90% !important;
     margin:5% !important;
        padding: 2% !important;
        border-radius: 10px ;
}
.btn-2:hover{
    background: none !important;
    color: blue !important;
    border: 1px solid blue !important;
}
@media(max-width:600px){
  .container{
    display: flex;
    flex-direction:column;
    justify-content:center;
    align-items:center;
   }
}@media(max-width:600px){
  .container-1{
     width:90% !important;
  }
}
    </style>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
   <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600&family=Poppins&display=swap" rel="stylesheet">

    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" type="image" href="pic\Screenshot (5).png" >
    <title> Fashion Basket</title>
</head>
<body>
<center>
<div class="container">
<?php 
            $row=mysqli_fetch_array($res)
            ?>
<div class="heee">
<h1  ><b style="color:blue; font-size:larger;"><?php echo $row['logo_name']?></b><b style="color:orangered;" ><?php echo $row['logo_last_name']?> </b></h1><br>


</div>


<div class="container-1">

<form action="login_up.php" method="post" enctype="multipart/form-data"  class="needs-validation " novalidate  >


<div class="mb-3 ">
    <input required class="form-control " type="email" name="email" id="email" aria-describedby="invalid-feedback" autocomplete="off" placeholder="Email Address">
    <div class="invalid-feedback ">please enter your email ! it is MUST! example: asdf@sdf.df</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 
<div class="mb-3 ">
    <input required class="form-control " type="password" name="password" id="password" aria-describedby="invalid-feedback" autocomplete="off" placeholder="Password">
    <div class="invalid-feedback ">please enter correct password!</div> 
    <div class="valid-feedback ">looks good!</div>
</div> 

  <input type="submit" class="btn  mt-1 mb-1" name="edit" value="Log in"  style="width:30%;">
<hr>
</form>

<a class="btn-2  nav-link" href="signup.php"> Create your Account</a>

</div>
</div>

</center>
<script>

(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

</script>
</body>
</html>